﻿using System;
using System.IO.Ports;
using System.Text;
using System.Windows;
using System.Windows.Controls;

namespace PicoSetting
{
    public partial class MainWindow : Window
    {
        private SerialPort serialPort;          // 시리얼 통신 담당 할 객체

        public MainWindow()
        {
            InitializeComponent();
            LoadAvailablePorts();               // 사용 가능한 포트 불러오기
            SetDefaultValues();                 // 디폴트 주소 값 설정
            BaudRateComboBox.SelectedIndex = 4; // Default: 115200 
        }
        // 디폴트 값 설정 함수 
        private void LoadSettingsFromFile(string filePath)
        {
            try
            {
                // 파일 읽기
                var lines = System.IO.File.ReadAllLines(filePath);

                // 각 줄을 파싱하여 UI에 적용
                foreach (var line in lines)
                {
                    if (line.StartsWith("MAC="))
                    {
                        var macParts = line.Substring(4).Split(':');
                        PicoMac1.Text = macParts[0];
                        PicoMac2.Text = macParts[1];
                        PicoMac3.Text = macParts[2];
                        PicoMac4.Text = macParts[3];
                        PicoMac5.Text = macParts[4];
                        PicoMac6.Text = macParts[5];
                    }
                    else if (line.StartsWith("IP="))
                    {
                        var ipParts = line.Substring(3).Split('.');
                        Pico_Ip1.Text = ipParts[0];
                        Pico_Ip2.Text = ipParts[1];
                        Pico_Ip3.Text = ipParts[2];
                        Pico_Ip4.Text = ipParts[3];
                    }
                    else if (line.StartsWith("Subnet="))
                    {
                        var subnetParts = line.Substring(7).Split('.');
                        Subnet1.Text = subnetParts[0];
                        Subnet2.Text = subnetParts[1];
                        Subnet3.Text = subnetParts[2];
                        Subnet4.Text = subnetParts[3];
                    }
                    else if (line.StartsWith("Gateway="))
                    {
                        var gatewayParts = line.Substring(8).Split('.');
                        Gateway1.Text = gatewayParts[0];
                        Gateway2.Text = gatewayParts[1];
                        Gateway3.Text = gatewayParts[2];
                        Gateway4.Text = gatewayParts[3];
                    }
                    else if (line.StartsWith("DNS="))
                    {
                        var dnsParts = line.Substring(4).Split('.');
                        DNS1.Text = dnsParts[0];
                        DNS2.Text = dnsParts[1];
                        DNS3.Text = dnsParts[2];
                        DNS4.Text = dnsParts[3];
                    }
                    else if (line.StartsWith("ServerIP="))
                    {
                        var serverIpParts = line.Substring(9).Split('.');
                        PICO_Server_IP1.Text = serverIpParts[0];
                        PICO_Server_IP2.Text = serverIpParts[1];
                        PICO_Server_IP3.Text = serverIpParts[2];
                        PICO_Server_IP4.Text = serverIpParts[3];
                    }
                    else if (line.StartsWith("Protocol="))
                    {
                        if (line.Substring(9) == "TCP")
                        {
                            TcpRadioButton.IsChecked = true;
                        }
                        else if (line.Substring(9) == "UDP")
                        {
                            UdpRadioButton.IsChecked = true;
                        }
                    }
                    else if (line.StartsWith("Port="))
                    {
                        PortTextBox.Text = line.Substring(5);
                    }
                    else if (line.StartsWith("Slave="))
                    {
                        SlaveTextBox.Text = line.Substring(6);
                    }
                    else if (line.StartsWith("ReadAddr="))
                    {
                        ReadAddrTextBox.Text = line.Substring(9);
                    }
                    else if (line.StartsWith("Block="))
                    {
                        BlockTextBox.Text = line.Substring(6);
                    }
                }

                // 성공 메시지 표시
                MessageBox.Show("설정을 성공적으로 로드했습니다!", "파일 읽기 성공", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                // 오류 메시지 표시
                MessageBox.Show($"파일 읽기 중 오류 발생: {ex.Message}", "오류", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void LoadFileButton_Click(object sender, RoutedEventArgs e)
        {
            // 파일 열기 대화상자 표시
            var openFileDialog = new Microsoft.Win32.OpenFileDialog
            {
                Filter = "텍스트 파일 (*.txt)|*.txt|모든 파일 (*.*)|*.*"
            };

            if (openFileDialog.ShowDialog() == true)
            {
                // 선택한 파일의 경로를 LoadSettingsFromFile 함수로 전달
                LoadSettingsFromFile(openFileDialog.FileName);
            }
        }


        private void SetDefaultValues()
        {
            // COM Port 디폴트 값
            if (ComPortComboBox.Items.Count > 0)
                ComPortComboBox.SelectedIndex = 0;

            // Baud Rate 디폴트 값
            BaudRateComboBox.SelectedIndex = 4; // 115200

            // PICOMAC 디폴트 값
            PicoMac1.Text = "DE";
            PicoMac2.Text = "AD";
            PicoMac3.Text = "BE";
            PicoMac4.Text = "EF";
            PicoMac5.Text = "FE";
            PicoMac6.Text = "ED";

            // PICOIP 디폴트 값
            Pico_Ip1.Text = "192";
            Pico_Ip2.Text = "168";
            Pico_Ip3.Text = "50";
            Pico_Ip4.Text = "11";

            // Subnet 디폴트 값
            Subnet1.Text = "255";
            Subnet2.Text = "255";
            Subnet3.Text = "255";
            Subnet4.Text = "0";

            // Gateway 디폴트 값
            Gateway1.Text = "192";
            Gateway2.Text = "168";
            Gateway3.Text = "50";
            Gateway4.Text = "254";

            // DNS 디폴트 값
            DNS1.Text = "168";
            DNS2.Text = "126";
            DNS3.Text = "63";
            DNS4.Text = "1";

            // PICO_Server_IP 디폴트 값
            PICO_Server_IP1.Text = "192";
            PICO_Server_IP2.Text = "168";
            PICO_Server_IP3.Text = "50";
            PICO_Server_IP4.Text = "10";

            // TCP/UDP 디폴트 값
            TcpRadioButton.IsChecked = true;

            // Port 디폴트 값
            PortTextBox.Text = "502";

            // 485 정보 디폴트 값
            SlaveTextBox.Text = "1";
            ReadAddrTextBox.Text = "0";
            BlockTextBox.Text = "90";
        }

        // 사용 가능한 COM 포트 로드
        private void LoadAvailablePorts()
        {
            ComPortComboBox.ItemsSource = SerialPort.GetPortNames(); //사용 가능한 포트를 가져온다.
            if (ComPortComboBox.Items.Count > 0)
                ComPortComboBox.SelectedIndex = 0;
        }

        // COM Reset 버튼 클릭
        private void ComReset_Click(object sender, RoutedEventArgs e)
        {
            LoadAvailablePorts();
        }

        // Open 버튼 클릭
        private void OpenButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (serialPort == null || !serialPort.IsOpen)
                {
                    serialPort = new SerialPort
                    {
                        PortName = ComPortComboBox.Text,
                        BaudRate = int.Parse((BaudRateComboBox.SelectedItem as ComboBoxItem)?.Content.ToString() ?? "115200"),
                        DataBits = 8,
                        StopBits = StopBits.One,
                        Parity = Parity.None,
                        RtsEnable = false,
                        DtrEnable = true,
                        Encoding = Encoding.ASCII
                    };

                    serialPort.DataReceived += SerialPort_DataReceived; // 데이터 수신 이벤트 연결
                    serialPort.Open(); // 시리얼 포트 열기
                    StatusTextBlock.Text = "Serial Port 상태: Open";

                    // 성공 메시지 표시
                    MessageBox.Show($"포트 {serialPort.PortName}이(가) 성공적으로 열렸습니다.", "포트 열기 성공", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch (Exception ex)
            {
                // 실패 메시지 표시
                MessageBox.Show($"포트를 여는 중 오류 발생: {ex.Message}", "포트 열기 오류", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }



        // Close 버튼 클릭
        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (serialPort != null && serialPort.IsOpen)
                {
                    serialPort.Close();
                    StatusTextBlock.Text = "Serial Port 상태: Close";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"포트를 닫는 중 오류 발생: {ex.Message}", "오류", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // Read 버튼 클릭
        private void ReadButton_Click(object sender, RoutedEventArgs e)
        {
            if (serialPort != null && serialPort.IsOpen)
            {
                serialPort.WriteLine("READ_SETTINGS");
            }
            else
            {
                MessageBox.Show("포트를 열어야 합니다.", "경고", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        // Write 버튼 클릭
        private void WriteButton_Click(object sender, RoutedEventArgs e)
        {
            if (serialPort != null && serialPort.IsOpen)
            {
                string mac = $"{PicoMac1.Text}:{PicoMac2.Text}:{PicoMac3.Text}:{PicoMac4.Text}:{PicoMac5.Text}:{PicoMac6.Text}";
                string ip = $"{Pico_Ip1.Text}.{Pico_Ip2.Text}.{Pico_Ip3.Text}.{Pico_Ip4.Text}";
                string subnet = $"{Subnet1.Text}.{Subnet2.Text}.{Subnet3.Text}.{Subnet4.Text}";
                string gateway = $"{Gateway1.Text}.{Gateway2.Text}.{Gateway3.Text}.{Gateway4.Text}";
                string dns = $"{DNS1.Text}.{DNS2.Text}.{DNS3.Text}.{DNS4.Text}";
                string serverIp = $"{PICO_Server_IP1.Text}.{PICO_Server_IP2.Text}.{PICO_Server_IP3.Text}.{PICO_Server_IP4.Text}";
                string protocol = TcpRadioButton.IsChecked == true ? "TCP" : "UDP";
                string port = PortTextBox.Text;
                string Slave = SlaveTextBox.Text;
                string ReadAddr = ReadAddrTextBox.Text;
                string Block = BlockTextBox.Text;

                string settings = $"WRITE;MAC={mac};IP={ip};Subnet={subnet};Gateway={gateway};DNS={dns};ServerIP={serverIp};Protocol={protocol};Port={port};Slave={Slave};ReadAddr={ReadAddr};Block={Block}";
                serialPort.WriteLine(settings);
            }
            else
            {
                MessageBox.Show("포트를 열어야 합니다.", "경고", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        // 시리얼 포트에서 데이터 수신
        private void SerialPort_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            try
            {
                string receivedData = serialPort.ReadLine();
                MessageBox.Show($"수신 데이터: {receivedData}", "데이터 수신", MessageBoxButton.OK);
                Dispatcher.Invoke(() =>
                {
                    // EEPROM 데이터를 UI에 반영
                    if (receivedData.StartsWith("MAC="))
                    {
                        var data = receivedData.Split(';');
                        foreach (var item in data)
                        {
                            if (item.StartsWith("MAC="))
                            {
                                var mac = item.Substring(4).Split(':');
                                PicoMac1.Text = mac[0];
                                
                                PicoMac2.Text = mac[1];
                                PicoMac3.Text = mac[2];
                                PicoMac4.Text = mac[3];
                                PicoMac5.Text = mac[4];
                                PicoMac6.Text = mac[5];
                            }
                            else if (item.StartsWith("IP="))
                            {
                                var ip = item.Substring(3).Split('.');
                                Pico_Ip1.Text = ip[0];
                                Pico_Ip2.Text = ip[1];
                                Pico_Ip3.Text = ip[2];
                                Pico_Ip4.Text = ip[3];
                            }
                            else if (item.StartsWith("Subnet="))
                            {
                                var subnet = item.Substring(7).Split('.');
                                Subnet1.Text = subnet[0];
                                Subnet2.Text = subnet[1];
                                Subnet3.Text = subnet[2];
                                Subnet4.Text = subnet[3];
                            }
                            else if (item.StartsWith("Gateway="))
                            {
                                var gateway = item.Substring(8).Split('.');
                                Gateway1.Text = gateway[0];
                                Gateway2.Text = gateway[1];
                                Gateway3.Text = gateway[2];
                                Gateway4.Text = gateway[3];
                            }
                            else if (item.StartsWith("DNS="))
                            {
                                var dns = item.Substring(4).Split('.');
                                DNS1.Text = dns[0];
                                DNS2.Text = dns[1];
                                DNS3.Text = dns[2];
                                DNS4.Text = dns[3];
                            }
                            else if (item.StartsWith("ServerIP="))
                            {
                                var serverIp = item.Substring(9).Split('.');
                                PICO_Server_IP1.Text = serverIp[0];
                                PICO_Server_IP2.Text = serverIp[1];
                                PICO_Server_IP3.Text = serverIp[2];
                                PICO_Server_IP4.Text = serverIp[3];
                            }
                            else if (item.StartsWith("Protocol="))
                            {
                                TcpRadioButton.IsChecked = item.Substring(9) == "TCP";
                                UdpRadioButton.IsChecked = item.Substring(9) == "UDP";
                            }
                            else if (item.StartsWith("Port="))
                            {
                                PortTextBox.Text = item.Substring(5);
                            }
                            else if (item.StartsWith("Slave="))
                            {
                                SlaveTextBox.Text = item.Substring(6);
                            }
                            else if (item.StartsWith("ReadAddr="))
                            {
                                ReadAddrTextBox.Text = item.Substring(9);
                            }
                            else if (item.StartsWith("Block="))
                            {
                                BlockTextBox.Text = item.Substring(6);
                            }
                        }
                    }

                });
            }
            catch (Exception ex)
            {
                Dispatcher.Invoke(() =>
                {
                    MessageBox.Show($"수신 중 오류 발생: {ex.Message}", "오류", MessageBoxButton.OK, MessageBoxImage.Error);
                });
            }
        }
        private void TestDebugButton_Click(object sender, RoutedEventArgs e)
        {
            if (serialPort != null && serialPort.IsOpen)
            {
                serialPort.WriteLine("TEST_DEBUG");
                MessageBox.Show("TEST_DEBUG 명령을 아두이노로 전송했습니다.", "전송 완료", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                MessageBox.Show("시리얼 포트를 먼저 열어야 합니다.", "포트 오류", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

    }
}